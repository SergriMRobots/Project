# ur_msgs

[![Build Status](http://build.ros.org/job/Mdev__ur_msgs__ubuntu_bionic_amd64/badge/icon)](http://build.ros.org/job/Mdev__ur_msgs__ubuntu_bionic_amd64)
[![Build Status: Travis CI](https://travis-ci.com/ros-industrial/ur_msgs.svg?branch=melodic-devel)](https://travis-ci.com/ros-industrial/ur_msgs)
[![Github Issues](https://img.shields.io/github/issues/ros-industrial/ur_msgs.svg)](http://github.com/ros-industrial/ur_msgs/issues)

[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)

[![support level: community](https://img.shields.io/badge/support%20level-community-lightgray.svg)](http://rosindustrial.org/news/2016/10/7/better-supporting-a-growing-ros-industrial-software-platform)

Message and service definitions for use with packages supporting and interacting with Universal Robots' robot controllers.

See the ROS wiki for more information: [wiki/ur_msgs](http://wiki.ros.org/ur_msgs).
