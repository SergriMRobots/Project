Реализация **moveit_servo**  взятая из репозитория проекта Moveit:
https://github.com/moveit/moveit/tree/1.1.14/moveit_ros/moveit_servo